# Changelog

## 0.2.0
- Per-car race clock (`elapsed`), `onResults` event, `close()`; late finishers get their own times.
- Demo page: tested-event-API lead copy, "Copy integration snippet" button, local-only use counters.
- Click test for the copy button (with and without `navigator.clipboard`).
- Zip now includes the README screenshots and this changelog.

## 0.1.0
- Lap timer, checkpoints, wrong-way warning, DNF results, HUD, touch controls, typings.
