// Type definitions for racekit-hud race-core. MIT License.

export const PHASE: Readonly<{
  IDLE: 'idle';
  COUNTDOWN: 'countdown';
  RACING: 'racing';
  FINISHED: 'finished';
}>;
export type Phase = 'idle' | 'countdown' | 'racing' | 'finished';

export interface RaceOptions {
  laps?: number;
  countdownSeconds?: number;
  playerName?: string;
  trackId?: string;
  storage?: { getItem(k: string): string | null; setItem(k: string, v: string): void } | null;
  checkpoints?: number;
  nextRaces?: string[];
}

export interface LapInfo { lap: number; totalLaps: number; time: number; isBestLap: boolean; raceTime: number }
export interface RaceResult {
  id: string; name: string; time: number | null; bestLap: number | null;
  isPlayer: boolean; pb: boolean; rank: number; dnf?: boolean;
}
export interface LapInvalid { valid: false; reason: string; missed: number; lap: number }
export interface RaceSummary {
  time: number; bestLap: number | null; lapTimes: number[]; position: number;
  raceRecord: boolean; lapRecord: boolean;
}
export interface RaceEvents {
  onCountdown: { value: number };
  onStart: {};
  onLap: LapInfo;
  onFinish: RaceSummary & { results: RaceResult[] };
  onReset: {};
  onWrongWay: { active: boolean };
  onPersonalBest: { race: number | null; lap: number | null };
  onLapInvalid: LapInvalid;
  onCheckpoint: { index: number; total: number; lap: number };
  onRoute: { action: 'restart' | 'next'; next: string | null };
}

export class RaceSession {
  constructor(opts?: RaceOptions);
  readonly totalLaps: number;
  phase: Phase;
  countdownLeft: number;
  raceTime: number;
  lap: number;
  lapTime: number;
  lapTimes: number[];
  bestLap: number | null;
  speed: number;
  position: number;
  totalRacers: number;
  wrongWay: boolean;
  results: RaceResult[];
  summary: RaceSummary | null;
  readonly currentLap: number;
  readonly inputEnabled: boolean;
  readonly hazardsActive: boolean;
  readonly personalBest: { lap: number | null; race: number | null };
  on<K extends keyof RaceEvents>(name: K, fn: (payload: RaceEvents[K]) => void): () => void;
  off<K extends keyof RaceEvents>(name: K, fn: (payload: RaceEvents[K]) => void): void;
  start(): boolean;
  update(dt: number): void;
  setState(s?: { speed?: number; position?: number; totalRacers?: number; wrongWay?: boolean }): void;
  readonly checkpoints: number;
  invalidLaps: number;
  crossCheckpoint(i: number): boolean;
  completeLap(): LapInfo | LapInvalid | null;
  reportDnf(id: string, name: string): boolean;
  reportFinish(id: string, name: string, time?: number | null): boolean;
  finish(): RaceSummary | null;
  reset(): void;
  choose(action: 'restart' | 'next'): boolean;
}

export function formatTime(t: number | null | undefined): string;
