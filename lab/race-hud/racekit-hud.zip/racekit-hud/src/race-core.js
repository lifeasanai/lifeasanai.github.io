// race-core.js - race state machine for racing/arcade games. No dependencies, no DOM.
// MIT License. See LICENSE.

export const PHASE = Object.freeze({
  IDLE: 'idle',
  COUNTDOWN: 'countdown',
  RACING: 'racing',
  FINISHED: 'finished',
});

const EVENTS = ['onCountdown', 'onStart', 'onLap', 'onFinish', 'onReset', 'onWrongWay', 'onPersonalBest', 'onRoute', 'onLapInvalid', 'onCheckpoint'];

export class RaceSession {
  /**
   * @param {object} [opts]
   * @param {number} [opts.laps=3]
   * @param {number} [opts.countdownSeconds=3]
   * @param {string} [opts.playerName='You']
   * @param {string} [opts.trackId='default']   key for personal bests
   * @param {object} [opts.storage]             getItem/setItem (e.g. localStorage); optional
   * @param {number} [opts.checkpoints=0]       if > 0, a lap only counts after checkpoints 1..N were crossed
   * @param {string[]} [opts.nextRaces=[]]      ids offered by choose('next')
   */
  constructor(opts = {}) {
    this.totalLaps = Math.max(1, Math.floor(opts.laps ?? 3));
    this.countdownSeconds = opts.countdownSeconds ?? 3;
    this.playerName = opts.playerName ?? 'You';
    this.trackId = opts.trackId ?? 'default';
    this.storage = opts.storage ?? null;
    this.checkpoints = Math.max(0, Math.floor(opts.checkpoints ?? 0));
    this.nextRaces = (opts.nextRaces ?? []).slice();
    this._handlers = {};
    this._best = this._loadBest();
    this._clear();
  }

  // ---- events -------------------------------------------------------------
  on(name, fn) {
    if (!EVENTS.includes(name)) throw new Error('Unknown event: ' + name);
    (this._handlers[name] ||= []).push(fn);
    return () => this.off(name, fn);
  }
  off(name, fn) {
    this._handlers[name] = (this._handlers[name] || []).filter((f) => f !== fn);
  }
  _emit(name, payload) {
    for (const fn of (this._handlers[name] || []).slice()) fn(payload);
  }

  // ---- state --------------------------------------------------------------
  _clear() {
    this.phase = PHASE.IDLE;
    this.countdownLeft = 0;
    this.raceTime = 0;
    this.lap = 0;            // completed laps
    this.lapTime = 0;        // current lap timer
    this.lapTimes = [];
    this._cp = new Set();
    this.invalidLaps = 0;
    this.bestLap = null;     // this race
    this.speed = 0;
    this.position = 1;
    this.totalRacers = 1;
    this.wrongWay = false;
    this.results = [];
    this.summary = null;
    this._lastCountdownInt = null;
  }

  /** Current lap number to display (1-based, capped at totalLaps). */
  get currentLap() {
    return Math.min(this.lap + 1, this.totalLaps);
  }
  /** Player may steer/accelerate. */
  get inputEnabled() {
    return this.phase === PHASE.RACING;
  }
  /** Hazards/collisions/damage should be applied. */
  get hazardsActive() {
    return this.phase === PHASE.RACING;
  }
  /** All-time best lap / race for this track: {lap, race} (null if none). */
  get personalBest() {
    return { ...this._best };
  }

  // ---- control ------------------------------------------------------------
  /** Begin the countdown. Ignored unless idle. Returns true if started. */
  start() {
    if (this.phase !== PHASE.IDLE) return false;
    if (this.countdownSeconds <= 0) {
      this._beginRace();
      return true;
    }
    this.phase = PHASE.COUNTDOWN;
    this.countdownLeft = this.countdownSeconds;
    this._lastCountdownInt = null;
    this._tickCountdownEvent();
    return true;
  }

  _tickCountdownEvent() {
    const n = Math.ceil(this.countdownLeft);
    if (n !== this._lastCountdownInt) {
      this._lastCountdownInt = n;
      this._emit('onCountdown', { value: n });
    }
  }

  _beginRace() {
    this.phase = PHASE.RACING;
    this.countdownLeft = 0;
    this._emit('onStart', {});
  }

  /** Advance by dt seconds. Call once per frame. */
  update(dt) {
    if (!(dt > 0)) return;
    if (this.phase === PHASE.COUNTDOWN) {
      this.countdownLeft -= dt;
      if (this.countdownLeft > 0) {
        this._tickCountdownEvent();
        return;
      }
      const leftover = -this.countdownLeft;
      this._beginRace();
      dt = leftover;
      if (!(dt > 0)) return;
    }
    if (this.phase === PHASE.RACING) {
      this.raceTime += dt;
      this.lapTime += dt;
    }
  }

  /** Feed live telemetry. Only applied while racing. */
  setState({ speed, position, totalRacers, wrongWay } = {}) {
    if (this.phase !== PHASE.RACING) return;
    if (speed !== undefined) this.speed = Math.max(0, speed);
    if (totalRacers !== undefined) this.totalRacers = Math.max(1, totalRacers);
    if (position !== undefined) this.position = Math.min(Math.max(1, position), this.totalRacers);
    if (wrongWay !== undefined && !!wrongWay !== this.wrongWay) {
      this.wrongWay = !!wrongWay;
      this._emit('onWrongWay', { active: this.wrongWay });
    }
  }

  /** Mark checkpoint i (1..checkpoints) as crossed for the current lap. */
  crossCheckpoint(i) {
    if (this.phase !== PHASE.RACING || !this.checkpoints) return false;
    if (!Number.isInteger(i) || i < 1 || i > this.checkpoints || this._cp.has(i)) return false;
    this._cp.add(i);
    this._emit('onCheckpoint', { index: i, total: this.checkpoints, lap: this.currentLap });
    return true;
  }

  /**
   * Call when the player crosses the line. With `checkpoints` set, a lap that missed any is rejected:
   * returns {valid:false, reason:'missed checkpoint 2'}, emits onLapInvalid, and the lap timer keeps running.
   * Otherwise finishes the race on the last lap and returns the lap info.
   */
  completeLap() {
    if (this.phase !== PHASE.RACING) return null;
    for (let i = 1; i <= this.checkpoints; i++) {
      if (!this._cp.has(i)) {
        const bad = { valid: false, reason: 'missed checkpoint ' + i, missed: i, lap: this.currentLap };
        this.invalidLaps += 1;
        this._cp.clear();
        this._emit('onLapInvalid', bad);
        return bad;
      }
    }
    this._cp.clear();
    const time = this.lapTime;
    this.lap += 1;
    this.lapTimes.push(time);
    const isBestLap = this.bestLap === null || time < this.bestLap;
    if (isBestLap) this.bestLap = time;
    this.lapTime = 0;
    const info = { lap: this.lap, totalLaps: this.totalLaps, time, isBestLap, raceTime: this.raceTime };
    this._emit('onLap', info);
    if (this.lap >= this.totalLaps) this.finish();
    return info;
  }

  /** Report an AI/remote racer finishing, so it shows in the results table. */
  reportFinish(id, name, time) {
    if (this.phase === PHASE.IDLE || this.phase === PHASE.COUNTDOWN) return false;
    if (this.results.some((r) => r.id === id)) return false;
    const t = typeof time === 'number' && isFinite(time) ? time : null; // missing time ranks last
    this.results.push({ id, name, time: t, bestLap: null, isPlayer: false, pb: false });
    this._rank();
    return true;
  }

  /** Report a racer who did not finish (crashed out, quit). Shown as DNF below all finishers. */
  reportDnf(id, name) {
    if (this.phase === PHASE.IDLE || this.phase === PHASE.COUNTDOWN) return false;
    if (this.results.some((r) => r.id === id)) return false;
    this.results.push({ id, name, time: null, bestLap: null, isPlayer: false, pb: false, dnf: true });
    this._rank();
    return true;
  }

  _rank() {
    const key = (r) => (r.dnf ? Infinity : r.time === null ? 1e15 : r.time);
    this.results.sort((a, b) => (key(a) === key(b) ? 0 : key(a) < key(b) ? -1 : 1));
    this.results.forEach((r, i) => (r.rank = i + 1));
    const me = this.results.find((r) => r.isPlayer);
    if (me) {
      this.position = me.rank;
      if (this.summary) this.summary.position = me.rank;
    }
  }

  /** End the race. Safe to call repeatedly: only the first call has any effect. */
  finish() {
    if (this.phase !== PHASE.RACING) return null;
    this.phase = PHASE.FINISHED;
    this.speed = 0;
    this.wrongWay = false;
    const time = this.raceTime;
    const prev = this._best;
    const raceRecord = prev.race === null || time < prev.race;
    const lapRecord = this.bestLap !== null && (prev.lap === null || this.bestLap < prev.lap);
    this.results.push({
      id: 'player', name: this.playerName, time, bestLap: this.bestLap, isPlayer: true, pb: raceRecord,
    });
    this.summary = { time, bestLap: this.bestLap, lapTimes: this.lapTimes.slice(), position: 1, raceRecord, lapRecord };
    this._rank();
    if (raceRecord) this._best.race = time;
    if (lapRecord) this._best.lap = this.bestLap;
    if (raceRecord || lapRecord) this._saveBest();
    this._emit('onFinish', { ...this.summary, results: this.results.map((r) => ({ ...r })) });
    if (raceRecord || lapRecord) {
      this._emit('onPersonalBest', { race: raceRecord ? time : null, lap: lapRecord ? this.bestLap : null });
    }
    return this.summary;
  }

  /** Back to a clean idle state. Personal bests are kept. */
  reset() {
    this._clear();
    this._emit('onReset', {});
  }

  /** Post-race routing. 'restart' resets and starts again; 'next' resets and emits the next race id. */
  choose(action) {
    if (this.phase !== PHASE.FINISHED) return false;
    if (action === 'restart') {
      this.reset();
      this._emit('onRoute', { action: 'restart', next: null });
      this.start();
      return true;
    }
    if (action === 'next') {
      const next = this.nextRaces.length ? this.nextRaces.shift() : null;
      this.reset();
      this._emit('onRoute', { action: 'next', next });
      return true;
    }
    return false;
  }

  // ---- persistence --------------------------------------------------------
  _key() {
    return 'racekit:best:' + this.trackId;
  }
  _loadBest() {
    const empty = { lap: null, race: null };
    try {
      const raw = this.storage && this.storage.getItem(this._key());
      if (!raw) return empty;
      const o = JSON.parse(raw);
      return {
        lap: typeof o.lap === 'number' ? o.lap : null,
        race: typeof o.race === 'number' ? o.race : null,
      };
    } catch {
      return empty;
    }
  }
  _saveBest() {
    try {
      if (this.storage) this.storage.setItem(this._key(), JSON.stringify(this._best));
    } catch { /* storage full or blocked: ignore */ }
  }
}

/** Format seconds as m:ss.mmm (null -> "--:--.---"). */
export function formatTime(t) {
  if (t === null || t === undefined || !isFinite(t)) return '--:--.---';
  const ms = Math.round(t * 1000);
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${m}:${String(s).padStart(2, '0')}.${String(ms % 1000).padStart(3, '0')}`;
}
