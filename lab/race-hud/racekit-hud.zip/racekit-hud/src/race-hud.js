// race-hud.js - Canvas 2D HUD for RaceSession. No dependencies. MIT License.
import { formatTime, PHASE } from './race-core.js';

const DEFAULTS = {
  font: 'Arial, Helvetica, sans-serif',
  color: '#ffffff',
  accent: '#ffd23f',
  warn: '#ff4d4d',
  good: '#5be37d',
  panel: 'rgba(10,12,20,0.78)',
  speedUnit: 'km/h',
};

export function ordinal(n) {
  const v = n % 100;
  if (v >= 11 && v <= 13) return n + 'th';
  return n + (['th', 'st', 'nd', 'rd'][n % 10] || 'th');
}

export class RaceHud {
  /**
   * @param {RaceSession} session
   * @param {object} [opts] theme overrides (font, color, accent, warn, good, panel, speedUnit)
   */
  constructor(session, opts = {}) {
    this.session = session;
    this.theme = { ...DEFAULTS, ...opts };
    this.buttons = [];   // {id, x, y, w, h, label} hit areas, valid after draw()
    this.clock = 0;      // seconds, for blinking; advanced by draw(ctx, w, h, dt)
    this.toast = null;   // {text, until} message such as an invalid lap
    session.on('onLapInvalid', (e) => this.showToast('LAP INVALID: ' + e.reason));
    session.on('onReset', () => { this.toast = null; });
  }

  _text(ctx, str, x, y, size, color, align = 'left', weight = 'bold') {
    ctx.font = `${weight} ${size}px ${this.theme.font}`;
    ctx.textAlign = align;
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = color || this.theme.color;
    ctx.fillText(str, x, y);
  }

  /** Show a centered warning for `seconds` (HUD clock time). */
  showToast(text, seconds = 3) {
    this.toast = { text, until: this.clock + seconds };
  }

  /** Draw the whole HUD. Call once per frame after your scene. dt (seconds) is optional, used for blinking. */
  draw(ctx, width, height, dt = 0) {
    const s = this.session, t = this.theme;
    this.clock += dt;
    this.buttons = [];
    ctx.save();
    const u = Math.max(0.5, Math.min(width / 800, height / 450)); // scale unit

    if (s.phase !== PHASE.IDLE) {
      // top-left: lap + position
      this._text(ctx, `LAP ${s.currentLap}/${s.totalLaps}`, 16 * u, 34 * u, 26 * u, t.color);
      this._text(ctx, `POS ${ordinal(s.position)}/${s.totalRacers}`, 16 * u, 64 * u, 22 * u, t.accent);
      // top-right: timers
      this._text(ctx, `TIME ${formatTime(s.raceTime)}`, width - 16 * u, 34 * u, 22 * u, t.color, 'right');
      this._text(ctx, `LAP  ${formatTime(s.lapTime)}`, width - 16 * u, 60 * u, 20 * u, t.color, 'right');
      const best = s.bestLap !== null ? s.bestLap : s.personalBest.lap;
      this._text(ctx, `BEST ${formatTime(best)}`, width - 16 * u, 84 * u, 20 * u, t.good, 'right');
      // bottom-right: speed
      this._text(ctx, String(Math.round(s.speed)), width - 70 * u, height - 34 * u, 56 * u, t.color, 'right');
      this._text(ctx, t.speedUnit, width - 16 * u, height - 34 * u, 18 * u, t.accent, 'right');
    }

    if (s.phase === PHASE.COUNTDOWN) {
      const n = Math.ceil(s.countdownLeft);
      this._text(ctx, String(n), width / 2, height / 2 + 40 * u, 140 * u, t.accent, 'center');
    } else if (s.phase === PHASE.RACING) {
      if (s.raceTime < 1) this._text(ctx, 'GO!', width / 2, height / 2 + 30 * u, 110 * u, t.good, 'center');
      if (s.wrongWay && Math.floor(this.clock * 3) % 2 === 0) {
        this._text(ctx, 'WRONG WAY', width / 2, height * 0.3, 54 * u, t.warn, 'center');
      }
    }
    if (this.toast && s.phase === PHASE.RACING) {
      if (this.clock < this.toast.until) this._text(ctx, this.toast.text, width / 2, height * 0.45, 34 * u, t.warn, 'center');
      else this.toast = null;
    }
    if (s.phase === PHASE.FINISHED) {
      this._drawResults(ctx, width, height, u);
    }
    ctx.restore();
  }

  _drawResults(ctx, width, height, u) {
    const s = this.session, t = this.theme, sum = s.summary;
    const rows = s.results.slice(0, 8);
    const pw = 440 * u, ph = (150 + rows.length * 28 + 70) * u;
    const px = (width - pw) / 2, py = (height - ph) / 2;
    ctx.fillStyle = t.panel;
    ctx.fillRect(px, py, pw, ph);
    this._text(ctx, 'RACE FINISHED', width / 2, py + 40 * u, 32 * u, t.accent, 'center');
    let y = py + 72 * u;
    this._text(ctx, `Time ${formatTime(sum.time)}   Best lap ${formatTime(sum.bestLap)}`, width / 2, y, 18 * u, t.color, 'center', 'normal');
    y += 26 * u;
    const pb = [];
    if (sum.raceRecord) pb.push('NEW RACE RECORD');
    if (sum.lapRecord) pb.push('NEW BEST LAP');
    this._text(ctx, pb.length ? pb.join(' + ') : 'No personal best this time', width / 2, y, 18 * u, pb.length ? t.good : t.color, 'center');
    y += 34 * u;
    for (const r of rows) {
      const c = r.isPlayer ? t.accent : t.color;
      this._text(ctx, r.dnf ? '-' : `${r.rank}.`, px + 24 * u, y, 18 * u, c);
      this._text(ctx, r.name, px + 60 * u, y, 18 * u, c);
      this._text(ctx, r.dnf ? 'DNF' : formatTime(r.time), px + pw - 24 * u, y, 18 * u, r.dnf ? t.warn : c, 'right');
      y += 28 * u;
    }
    const bw = 150 * u, bh = 40 * u, by = py + ph - 56 * u;
    const defs = [['restart', 'Restart (R)'], ['next', 'Next race (N)']];
    defs.forEach(([id, label], i) => {
      const bx = width / 2 + (i === 0 ? -bw - 10 * u : 10 * u);
      ctx.fillStyle = t.accent;
      ctx.fillRect(bx, by, bw, bh);
      this._text(ctx, label, bx + bw / 2, by + 27 * u, 17 * u, '#111', 'center');
      this.buttons.push({ id, x: bx, y: by, w: bw, h: bh, label });
    });
  }

  /** Pass canvas-space pointer coords. Returns the action routed ('restart'/'next') or null. */
  click(x, y) {
    const b = this.buttons.find((b) => x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h);
    if (!b) return null;
    return this.session.choose(b.id) ? b.id : null;
  }

  /** Optional keyboard shortcut helper: R = restart, N = next. Returns the action or null. */
  key(k) {
    const a = { r: 'restart', n: 'next' }[String(k).toLowerCase()];
    return a && this.session.choose(a) ? a : null;
  }
}
