// Type definitions for racekit-hud race-hud. MIT License.
import type { RaceSession } from './race-core.js';

export interface HudTheme {
  font: string;
  color: string;
  accent: string;
  warn: string;
  good: string;
  panel: string;
  speedUnit: string;
}
export interface HudButton { id: string; x: number; y: number; w: number; h: number; label: string }

export function ordinal(n: number): string;

export class RaceHud {
  constructor(session: RaceSession, opts?: Partial<HudTheme>);
  session: RaceSession;
  theme: HudTheme;
  buttons: HudButton[];
  clock: number;
  toast: { text: string; until: number } | null;
  showToast(text: string, seconds?: number): void;
  draw(ctx: CanvasRenderingContext2D, width: number, height: number, dt?: number): void;
  click(x: number, y: number): unknown;
  key(k: string): unknown;
}
