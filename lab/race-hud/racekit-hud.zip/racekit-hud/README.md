# racekit-hud

A dependency-free ES module for racing/arcade games on Canvas, Phaser or three.js. It gives you the race HUD (speed, lap counter, current/best lap, position, countdown, wrong-way warning) **and** the post-race logic every devlog re-implements: finish, results table, personal-best detection, restart/next-race routing, and a safe state (no double finish, no input or hazards after finish, clean reset). Events API: `onLap`, `onFinish`, `onReset` and more. MIT license.

## Who it is for
Indie web-game devs who keep re-writing the same lap/finish/results code and HUD drawing.

## Integrate in about 12 lines
```js
import { RaceSession } from './src/race-core.js';
import { RaceHud } from './src/race-hud.js';
const race = new RaceSession({ laps: 3, trackId: 'oval', storage: localStorage, nextRaces: ['track-2'] });
const hud = new RaceHud(race);                              // draws onto any Canvas 2D context
race.on('onLap', (l) => console.log('lap', l.lap, l.time)); // also onFinish, onReset, onStart, onPersonalBest, onRoute
race.start();                                               // countdown, then racing
function frame(dt) {                                        // your game loop, dt in seconds
  race.update(dt);
  race.setState({ speed: 120, position: 1, totalRacers: 4, wrongWay: false }); // live telemetry
  hud.draw(ctx, canvas.width, canvas.height, dt);          // draw after your scene
}
// when your game decides the lap is valid: race.completeLap();  (last lap finishes the race)
```
(The example is run by `tests/readme.test.mjs`.) Pointer/keys for the results panel: `hud.click(x, y)` and `hud.key('r' | 'n')`.

## Phaser and three.js
The HUD only needs a 2D canvas context, so render it to an offscreen canvas and show that as a texture. (These snippets follow the public Phaser 3 and three.js APIs but were not run against those libraries in this build; the HUD side is the same as the tested example above.)

Phaser 3:
```js
const hudCanvas = document.createElement('canvas'); hudCanvas.width = 800; hudCanvas.height = 450;
const hudCtx = hudCanvas.getContext('2d');
// in create():
this.hudTex = this.textures.addCanvas('hud', hudCanvas);
this.add.image(0, 0, 'hud').setOrigin(0).setScrollFactor(0).setDepth(1000);
// in update(time, delta):
const dt = delta / 1000;
race.update(dt);
hudCtx.clearRect(0, 0, 800, 450);
hud.draw(hudCtx, 800, 450, dt);
this.hudTex.refresh();
```

three.js:
```js
const hudCanvas = document.createElement('canvas'); hudCanvas.width = 800; hudCanvas.height = 450;
const hudCtx = hudCanvas.getContext('2d');
const tex = new THREE.CanvasTexture(hudCanvas);
const hudScene = new THREE.Scene();
const hudCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
hudScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshBasicMaterial({ map: tex, transparent: true })));
// each frame:
race.update(dt);
hudCtx.clearRect(0, 0, 800, 450);
hud.draw(hudCtx, 800, 450, dt);
tex.needsUpdate = true;
renderer.autoClear = false; renderer.clear(); renderer.render(scene, camera); renderer.render(hudScene, hudCam);
```
For clicks on the results panel, convert pointer coordinates to the 800x450 canvas space and call `hud.click(x, y)`.

## Files
- `src/race-core.js` - state machine, no DOM (`RaceSession`, `PHASE`, `formatTime`).
- `src/race-hud.js` - Canvas 2D drawing (`RaceHud`). Theme options: `font, color, accent, warn, good, panel, speedUnit`.
- `dist/racekit-hud.iife.js` - classic-script build (`window.RaceKit`) so pages work from `file://` without a server. Made by `python build.py`.
- `dist/racekit-hud.zip` - module + demo + LICENSE + README.
- `lab/race-hud/index.html` - playable demo: open it directly in a browser, fully offline.

## Core API
- `new RaceSession({ laps, countdownSeconds, checkpoints, playerName, trackId, storage, nextRaces })`
- `start()`, `update(dt)`, `setState({speed, position, totalRacers, wrongWay})`, `completeLap()`, `finish()` (repeat calls ignored), `reportFinish(id, name, time)` for AI racers, `reportDnf(id, name)` (DNF rows rank below finishers), `choose('restart' | 'next')`, `reset()`.
- Checkpoints: pass `checkpoints: N`, call `crossCheckpoint(i)` (1..N) as the player passes each one. `completeLap()` then returns `{valid:false, reason:'missed checkpoint 2'}` and emits `onLapInvalid` if one was skipped (the lap is not counted). Without `checkpoints`, every `completeLap()` counts.
- Getters: `phase`, `inputEnabled`, `hazardsActive` (false outside racing), `currentLap`, `personalBest`.
- Events (`race.on(name, fn)` returns an unsubscribe function): `onCountdown`, `onStart`, `onCheckpoint`, `onLap`, `onLapInvalid`, `onFinish`, `onReset`, `onWrongWay`, `onPersonalBest`, `onRoute`.
- TypeScript typings: `src/race-core.d.ts`, `src/race-hud.d.ts` (wired through package.json `types`/`exports`; not compiled with `tsc` here).

## Screenshot
Made by `python make_screenshots.py` (headless Chrome, needs `../_tools/browser_check.py`) into `screenshots/`:

![Mid-race HUD](screenshots/mid-race-hud.png)
![Wrong-way warning](screenshots/wrong-way-warning.png)
![Results with DNF and best lap](screenshots/results.png)

(Run the script once to create the images; they are not committed yet.) The demo folder `lab/race-hud/` is self-contained (page, `racekit-hud.iife.js`, `racekit-hud.zip`), so it can be copied to `site/lab/race-hud/`. The page has a "Run edge-case test" button and a "Download zip" link.
- `storage` is optional (anything with `getItem`/`setItem`); failures are swallowed. If `localStorage` itself throws on access, pass `null`.

## Test
```
python test_race_core.py     # runs all Node tests (needs Node 18+) and the zip check
python build.py              # rebuild dist/ first if you changed src/
```
Covered: 3 laps + finish + duplicate finish ignored + reset (core), draw calls with a fake canvas context (HUD), the demo page script driven headlessly through a full race, the README example, and the zip contents.

## Known limits
- Deciding that a checkpoint was crossed (geometry) is your game's job; the kit only enforces the order/completeness. The demo ignores checkpoint crossings made off the track, so infield shortcuts are rejected.
- The demo is a simple top-down oval. Keyboard plus on-canvas touch buttons (appear after the first touch; tested with synthetic pointer events, not on a physical phone). No gamepad.
- The test suite uses a fake DOM (`tests/autoplay.test.mjs` plays the whole `?autoplay=1` edge-case run: wrong way, invalid lap, DNF, results). `test_race_core.py` also runs `browser_check.py` in headless Chrome with `?autoplay=1` and asserts 0 console errors (skipped if Chrome or the tool is missing).
- The wrong-way warning needs the car to move (speed > 25) against the track direction. Key `W` forces it while racing (not on the start screen or countdown).
- Phaser/three.js snippets are untested against those libraries.