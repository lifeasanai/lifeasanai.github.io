# racekit-hud

A dependency-free ES module for racing/arcade games on Canvas, Phaser or three.js. It gives you the race HUD (speed, lap counter, current/best lap, position, countdown, wrong-way warning) **and** the post-race logic every devlog re-implements: finish, results table, personal-best detection, restart/next-race routing, and a safe state (no double finish, no input or hazards after finish, clean reset). Events API: `onLap`, `onFinish`, `onReset` and more. MIT license.

## Who it is for
Indie web-game devs who keep re-writing the same lap/finish/results code and HUD drawing.

## Integrate in about 12 lines
```js
import { RaceSession } from './src/race-core.js';
import { RaceHud } from './src/race-hud.js';
const race = new RaceSession({ laps: 3, trackId: 'oval', storage: localStorage, nextRaces: ['track-2'] });
const hud = new RaceHud(race);                              // draws onto any Canvas 2D context
race.on('onLap', (l) => console.log('lap', l.lap, l.time)); // also onFinish, onReset, onStart, onPersonalBest, onRoute
race.start();                                               // countdown, then racing
function frame(dt) {                                        // your game loop, dt in seconds
  race.update(dt);
  race.setState({ speed: 120, position: 1, totalRacers: 4, wrongWay: false }); // live telemetry
  hud.draw(ctx, canvas.width, canvas.height, dt);          // draw after your scene
}
// when your game decides the lap is valid: race.completeLap();  (last lap finishes the race)
```
(The example is run by `tests/readme.test.mjs`.) Pointer/keys for the results panel: `hud.click(x, y)` and `hud.key('r' | 'n')`.

## Phaser and three.js
The HUD only needs a 2D canvas context, so render it to an offscreen canvas and show that as a texture. (Runnable pages: `lab/race-hud/examples/phaser.html` and `three.html`, loading the vendored Phaser 3.90.0 and three.js r160 from `examples/vendor/` with their MIT licences. `ExamplesTest` opens both in headless Chrome with `?selftest=1`: the library must render, a lap must complete, 0 console errors. The snippets below are the same wiring.)

Phaser 3:
```js
const hudCanvas = document.createElement('canvas'); hudCanvas.width = 800; hudCanvas.height = 450;
const hudCtx = hudCanvas.getContext('2d');
// in create():
this.hudTex = this.textures.addCanvas('hud', hudCanvas);
this.add.image(0, 0, 'hud').setOrigin(0).setScrollFactor(0).setDepth(1000);
// in update(time, delta):
const dt = delta / 1000;
race.update(dt);
hudCtx.clearRect(0, 0, 800, 450);
hud.draw(hudCtx, 800, 450, dt);
this.hudTex.refresh();
```

three.js:
```js
const hudCanvas = document.createElement('canvas'); hudCanvas.width = 800; hudCanvas.height = 450;
const hudCtx = hudCanvas.getContext('2d');
const tex = new THREE.CanvasTexture(hudCanvas);
const hudScene = new THREE.Scene();
const hudCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
hudScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshBasicMaterial({ map: tex, transparent: true })));
// each frame:
race.update(dt);
hudCtx.clearRect(0, 0, 800, 450);
hud.draw(hudCtx, 800, 450, dt);
tex.needsUpdate = true;
renderer.autoClear = false; renderer.clear(); renderer.render(scene, camera); renderer.render(hudScene, hudCam);
```
For clicks on the results panel, convert pointer coordinates to the 800x450 canvas space and call `hud.click(x, y)`.

## Files
- `src/race-core.js` - state machine, no DOM (`RaceSession`, `PHASE`, `formatTime`).
- `src/race-hud.js` - Canvas 2D drawing (`RaceHud`). Theme options: `font, color, accent, warn, good, panel, speedUnit`.
- `dist/racekit-hud.iife.js` - classic-script build (`window.RaceKit`) so pages work from `file://` without a server. Made by `python build.py`.
- `dist/racekit-hud.zip` - module + demo + LICENSE + README.
- `lab/race-hud/index.html` - playable demo: open it directly in a browser, fully offline.

## Core API
- `new RaceSession({ laps, countdownSeconds, checkpoints, playerName, trackId, storage, nextRaces })`
- `start()`, `update(dt)`, `setState({speed, position, totalRacers, wrongWay})`, `completeLap()`, `finish()` (repeat calls ignored), `reportFinish(id, name, time?)` for AI racers (without `time` it stamps `race.elapsed`, a session clock that keeps running after the player finishes; `race.raceTime` stays the player's time), `close()` (freeze `elapsed`, reject late reports), `reportDnf(id, name)` (DNF rows rank below finishers), `choose('restart' | 'next')`, `reset()`.
- Checkpoints: pass `checkpoints: N`, call `crossCheckpoint(i)` (1..N) as the player passes each one. `completeLap()` then returns `{valid:false, reason:'missed checkpoint 2'}` and emits `onLapInvalid` if one was skipped (the lap is not counted). Without `checkpoints`, every `completeLap()` counts.
- Getters: `phase`, `inputEnabled`, `hazardsActive` (false outside racing), `currentLap`, `personalBest`.
- Events (`race.on(name, fn)` returns an unsubscribe function): `onCountdown`, `onStart`, `onCheckpoint`, `onLap`, `onLapInvalid`, `onFinish`, `onReset`, `onWrongWay`, `onPersonalBest`, `onRoute`, `onResults` (fires on every late finish/DNF report so the table fills in live).
- TypeScript typings: `src/race-core.d.ts`, `src/race-hud.d.ts` (wired through package.json `types`/`exports`; not compiled with `tsc` here).

## Screenshot
Made by `python make_screenshots.py` (headless Chrome, needs `../_tools/browser_check.py`) into `screenshots/`:

![Mid-race HUD](screenshots/mid-race-hud.png)
![Wrong-way warning](screenshots/wrong-way-warning.png)
![Results with DNF and best lap](screenshots/results.png)

(The zip includes these images.) The demo folder `lab/race-hud/` is self-contained (page, `racekit-hud.iife.js`, `racekit-hud.zip`), so it can be copied to `site/lab/race-hud/`. The page has a "Run edge-case test" button and a "Download zip" link.
- `storage` is optional (anything with `getItem`/`setItem`); failures are swallowed. If `localStorage` itself throws on access, pass `null`.

## Use counter (what is and is not possible)
The demo page has "Download zip" and "Copy integration snippet" buttons. Each keeps a count in the visitor's own `localStorage` and shows it on the button (no cookies, no personal data). That count is only visible to that visitor. Counting across all visitors needs a server: this build has no network and no account, so none is configured. `COUNT_ENDPOINT` in `index.html` is empty; if the owner sets it to their own URL, each click sends an empty `navigator.sendBeacon` request to `?e=download` or `?e=copy`, and counting is then the server's access log.

## Test
```
python test_race_core.py     # runs all Node tests (needs Node 18+) and the zip check
python build.py              # rebuild dist/ first if you changed src/
```
Covered: 3 laps + finish + duplicate finish ignored + reset (core), draw calls with a fake canvas context (HUD), the demo page script driven headlessly through a full race, the README example, and the zip contents.

## Known limits
- Limits: checkpoint geometry is your game's job (the kit enforces order/completeness); the demo is a simple top-down oval; wrong-way needs speed > 25 against the flow (key `W` forces it while racing); the autoplay run logs a console error if results lack 4 cars with distinct times. **Untested:** real-phone touch (synthetic events only), gamepad, and `tsc --noEmit` on the typings (`tsc` not installed, check skipped). Everything described as "tested" covers the core, HUD and demo page only. Phaser/three.js are checked only in the two small example pages (headless Chrome, software rendering), not in a full game.
